#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    connect(ui->addButton, &QPushButton::clicked, this, &MainWindow::addStudent);
    connect(ui->displayButton, &QPushButton::clicked, this, &MainWindow::displayStudents);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::addStudent() {
    QString name = ui->nameEdit->text();
    QString birthDate = ui->birthDateEdit->text();
    QString phoneNumber = ui->phoneNumberEdit->text();
    QString address = ui->addressEdit->text();
    QString groupNumber = ui->groupNumberEdit->text();

    if (name.isEmpty() || birthDate.isEmpty() || phoneNumber.isEmpty() || address.isEmpty() || groupNumber.isEmpty()) {
        QMessageBox::warning(this, "Error", "Будьласка заповніть усі поля.");
        return;
    }

    Student student;
    student.name = name;
    student.birthDate = birthDate;
    student.phoneNumber = phoneNumber;
    student.address = address;
    student.groupNumber = groupNumber;

    students.append(student);

    QMessageBox::information(this, "Success", "Студента додано.");

    clearInputFields();
}

void MainWindow::displayStudents() {
    QString studentInfo;
    for (const auto &student : students) {
        studentInfo += "Ім'я: " + student.name + "\n"
                       + "Дата народження: " + student.birthDate + "\n"
                       + "Номер телефону: " + student.phoneNumber + "\n"
                       + "Адреса: " + student.address + "\n"
                       + "Група: " + student.groupNumber + "\n\n";
    }

    if (studentInfo.isEmpty()) {
        QMessageBox::information(this, "Нема студентів", "Покищо нема студентів.");
    } else {
        QMessageBox::information(this, "Список студентів", studentInfo);
    }
}

void MainWindow::clearInputFields() {
    ui->nameEdit->clear();
    ui->birthDateEdit->clear();
    ui->phoneNumberEdit->clear();
    ui->addressEdit->clear();
    ui->groupNumberEdit->clear();
}
