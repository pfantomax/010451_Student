#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class Student {
public:
    QString name;
    QString birthDate;
    QString phoneNumber;
    QString address;
    QString groupNumber;
};

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void addStudent();
    void displayStudents();
    void clearInputFields();

private:
    Ui::MainWindow *ui;
    QList<Student> students;
};

#endif // MAINWINDOW_H
